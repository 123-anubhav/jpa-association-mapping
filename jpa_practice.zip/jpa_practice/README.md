# jpa-association-mapping
jpa-association-mapping [1-1,1-m]
